for i in []:
    if i > 4:
        print("Found nuber grater than 5")
        break
else:
    print("all the numbers are lower than 5")

